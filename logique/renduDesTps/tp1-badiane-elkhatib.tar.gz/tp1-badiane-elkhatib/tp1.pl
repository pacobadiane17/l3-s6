contenu(princesse).
contenu(tigre).
contenu(rien).

pancarte1(tigre, Y) :- contenu(Y).
pancarte1(X, princesse) :- contenu(X).
pancarte2(princesse, Y) :- contenu(Y).

salle1(X,Y) :- pancarte1(X,Y), pancarte2(X,Y).

pancarte3(princesse, tigre).
pancarte4(princesse,tigre).
pancarte4(tigre,princesse).

salle2(X,Y):- contenu(X), contenu(Y), pancarte3(X,Y), not(pancarte4(X,Y)).
salle2(X,Y):- contenu(X), contenu(Y), pancarte4(X,Y), not(pancarte3(X,Y)).

sol_salle2 :- salle2(X,Y), write('Porte 1 : '), write(X), 
		write('\n Porte 2 : '), write(Y).

pancarte31(tigre,princesse,rien).
pancarte31(princesse,tigre,rien).

pancarte32(tigre,rien,princesse).
pancarte32(tigre,princesse,rien).

pancarte33(tigre,princesse,rien).
pancarte33(princesse,tigre,rien).

porte1(X,Y,Z) :- pancarte31(X,Y,Z), pancarte33(X,Y,Z), not(pancarte32(X,Y,Z)).
porte2(X,Y,Z) :- pancarte32(X,Y,Z), not(pancarte31(X,Y,Z)), not(pancarte33(X,Y,Z)).
porte3(X,Y,Z) :- pancarte33(X,Y,Z), pancarte31(X,Y,Z), not(pancarte32(X,Y,Z)).

salle3(X,Y,Z) :- porte1(X,Y,Z), porte3(X,Y,Z), not(porte2(X,Y,Z)).
salle3(X,Y,Z) :- porte2(X,Y,Z), not(porte1(X,Y,Z)), not(porte3(X,Y,Z)).
